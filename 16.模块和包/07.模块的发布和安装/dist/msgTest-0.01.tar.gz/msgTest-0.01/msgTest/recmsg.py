def test1():
	print("====test1===receive=======")
def test2():
	print("====test2===receiv=======")
