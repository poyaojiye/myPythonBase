__all__ = ["sendmsg"]

from . import *
# print ("这句话在导入这个包是会被执行")
